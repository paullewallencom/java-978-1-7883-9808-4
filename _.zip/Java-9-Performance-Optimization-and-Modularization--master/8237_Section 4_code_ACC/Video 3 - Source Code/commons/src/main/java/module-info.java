module twitterApp.commons {
    requires twitter4j.core;
    exports twitterApp.commons;
}