module twitterApp.app {
    requires twitterApp.commons;
    requires twitter4j.core;
    requires java.logging;
}